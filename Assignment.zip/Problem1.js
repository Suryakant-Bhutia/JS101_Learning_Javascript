console.log("Masai School");
console.log("A Transformation In Education");