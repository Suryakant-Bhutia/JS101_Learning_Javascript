
let x=10;
let y=2;

console.log((x+y)**y);