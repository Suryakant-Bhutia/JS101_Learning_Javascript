let r1="Name-Rohan Sharma";
console.log(r1);

let r2="School-Sai International School";
console.log(r2);

let r3="Grade-9th";
console.log(r3);

let r4="Sec-A";
console.log(r4);

let r5="Roll NO-05";
console.log(r5);

let r6="            Marks Sheet                ";
console.log(r6);

let r7="Subjects    Total marks    obt.marks ";
console.log(r7);

let r8="Maths          100            94";
console.log(r8);

let r9="Science        100            92";
console.log(r9);

let r10="English        100            87";
console.log(r10);

let r11="Total          300            273";
console.log(r11);

let r12="verdict=PASS";
console.log(r12);