let name="Suryakanta Bhutia";
let age=20;

console.log(name,age);