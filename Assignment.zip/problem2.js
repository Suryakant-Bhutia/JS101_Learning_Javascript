let name1="Name=Suryakanta Bhutia";
console.log(name1);

let name2="Father's Name=Sunanda Bhutia";
console.log(name2);

let name3="Mother's Name=Subhadra Khilar";
console.log(name3);